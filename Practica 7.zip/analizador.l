
%{
#include "analizador.tab.h"
#include <stdio.h>

extern int error_lexico;
%}

%option noyywrap

%%

"if" {
    printf("TOKEN: IF -> %s\n", yytext);
    return IF;
}

"then" {
    printf("TOKEN: THEN -> %s\n", yytext);
    return THEN;
}

">=" {
    printf("TOKEN: MAYOR_IGUAL -> %s\n", yytext);
    return MAYOR_IGUAL;
}

"<=" {
    printf("TOKEN: MENOR_IGUAL -> %s\n", yytext);
    return MENOR_IGUAL;
}

"==" {
    printf("TOKEN: IGUAL -> %s\n", yytext);
    return IGUAL;
}

"!=" {
    printf("TOKEN: DIFERENTE -> %s\n", yytext);
    return DIFERENTE;
}

">" {
    printf("TOKEN: MAYOR -> %s\n", yytext);
    return MAYOR;
}

"<" {
    printf("TOKEN: MENOR -> %s\n", yytext);
    return MENOR;
}

"=" {
    printf("TOKEN: ASIGNACION -> %s\n", yytext);
    return ASIGNACION;
}

"+" {
    printf("TOKEN: MAS -> %s\n", yytext);
    return MAS;
}

"-" {
    printf("TOKEN: MENOS -> %s\n", yytext);
    return MENOS;
}

"*" {
    printf("TOKEN: MULTIPLICACION -> %s\n", yytext);
    return MULTIPLICACION;
}

"/" {
    printf("TOKEN: DIVISION -> %s\n", yytext);
    return DIVISION;
}

"(" {
    printf("TOKEN: PAR_IZQ -> %s\n", yytext);
    return PAR_IZQ;
}

")" {
    printf("TOKEN: PAR_DER -> %s\n", yytext);
    return PAR_DER;
}

"{" {
    printf("TOKEN: LLAVE_IZQ -> %s\n", yytext);
    return LLAVE_IZQ;
}

"}" {
    printf("TOKEN: LLAVE_DER -> %s\n", yytext);
    return LLAVE_DER;
}

";" {
    printf("TOKEN: PUNTO_COMA -> %s\n", yytext);
    return PUNTO_COMA;
}

[0-9]+ {
    printf("TOKEN: NUMERO -> %s\n", yytext);
    return NUMERO;
}

[a-zA-Z_][a-zA-Z0-9_]* {
    printf("TOKEN: IDENTIFICADOR -> %s\n", yytext);
    return IDENTIFICADOR;
}

[ \t\r\n]+ {
   
}

. {
    printf("ERROR LEXICO: caracter no reconocido -> %s\n", yytext);
    error_lexico = 1;
    return ERROR_LEXICO;
}

%%
