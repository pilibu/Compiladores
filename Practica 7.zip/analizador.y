
%{
#include <stdio.h>

int yylex(void);
void yyerror(const char *s);

int error_lexico = 0;
%}

%define parse.error verbose

%token IF THEN
%token MAYOR_IGUAL MENOR_IGUAL IGUAL DIFERENTE
%token MAYOR MENOR ASIGNACION
%token MAS MENOS MULTIPLICACION DIVISION
%token PAR_IZQ PAR_DER LLAVE_IZQ LLAVE_DER
%token PUNTO_COMA
%token NUMERO IDENTIFICADOR ERROR_LEXICO

%left MAS MENOS
%left MULTIPLICACION DIVISION

%%

programa:
    sentencia_condicional
    ;

sentencia_condicional:
    IF PAR_IZQ condicion PAR_DER THEN
    LLAVE_IZQ asignacion LLAVE_DER
    ;

condicion:
    expresion operador_relacional expresion
    ;

operador_relacional:
    MAYOR
    | MENOR
    | MAYOR_IGUAL
    | MENOR_IGUAL
    | IGUAL
    | DIFERENTE
    ;

asignacion:
    IDENTIFICADOR ASIGNACION expresion PUNTO_COMA
    ;

expresion:
    expresion MAS termino
    | expresion MENOS termino
    | termino
    ;

termino:
    termino MULTIPLICACION factor
    | termino DIVISION factor
    | factor
    ;

factor:
    NUMERO
    | IDENTIFICADOR
    | PAR_IZQ expresion PAR_DER
    ;

%%

void yyerror(const char *s) {
    if (!error_lexico) {
        fprintf(stderr, "ERROR SINTACTICO: %s\n", s);
    }
}

int main(void) {
    printf("Iniciando analisis...\n\n");

    int resultado = yyparse();

    printf("\n");

    if (error_lexico) {
        printf("Se detectaron errores lexicos.\n");
        return 1;
    }

    if (resultado == 0) {
        printf("Estructura sintactica correcta.\n");
        return 0;
    }

    printf("El codigo contiene errores sintacticos.\n");
    return 1;
}
